var options = {luminosity:35}
