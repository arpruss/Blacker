var options = {black:35,white:15,backblack:12,backwhite:5,ignorelinks:true}
